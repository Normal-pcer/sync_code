#if false
print("Hello,World")
""" 
#endif
#include <bits/stdc++.h>

int main() {
    std::cout << "Hello,World!" << std::endl;
    return 0;
}

#if false
""" 
#endif
