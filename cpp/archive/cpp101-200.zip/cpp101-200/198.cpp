#include <bits/stdc++.h>
#define initDebug DEBUG_MODE=(argc-1)&&!strcmp("-d", argv[1])
#define debug if(DEBUG_MODE)
#define log(f, a...) debug printf(f, ##a);
#define upto(i,n) for(int i=1;i<=(n);i++)
#define from(i,b,e) for(int i=(b);i<=(e);i++)
#define rev(i,e,b) for(int i=(e);i>=(b);i--)
#define main() main(int argc, char const *argv[])
#define optimizeIO std::ios::sync_with_stdio(false); std::cin.tie(0); std::cout.tie(0);
#define chkMax(base,cmp...) (base=std::max({(base),##cmp}))
#define chkMin(base,cmp...) (base=std::min({(base),##cmp}))
#define chkMaxEx(base,exchange,other,cmp...) {auto __b__=base;if(__b__!=chkMax(base,##cmp)){exchange;} else other;}
#define chkMinEx(base,exchange,other,cmp...) {auto __b__=base;if(__b__!=chkMin(base,##cmp)){exchange;} else other;}
#define update(base,op,modify...) base=op((base),##modify)
#define ensure(con, otw) ((con)? (con): (otw))
#define check(v, con, otw) (((v) con)? (v): (otw))
#define optional(ptr) if(ptr)ptr
#define never if(0)
#define always if(1)
#define bitOr(x,y) (((x)&(y))^(((x)^(y))|(~(x)&(y))))
#define Infinity 2147483647
#define putInt(n) printf("%d\n",(n))
#define compare(x,y,g,e,l) (((x)>(y))?(g):(((x)<(y))?(l):(e)))
bool DEBUG_MODE=false;
typedef long long ll; typedef unsigned long long ull;
inline void batchOutput(int *begin, int n, const char *format){upto(i, n)printf(format, begin[i]);printf("\n");} inline void batchOutput(int*begin, int n) {batchOutput(begin,n,"%3d ");}
#define batchOutput2d(b, r, c, fmt) upto(i,r){upto(j,c)printf(fmt,b[i][j]);printf("\n");}
template <class T=int>inline T read(){ T x=0;int f=1;char c;while((c=getchar())<'0'||c>'9')if(c=='-')f=-1;do{x=(((x<<2)+x)<<1)+c-'0';}while((c=getchar())>='0'&&c<='9');return x*f; }


const int _N = 505; int N;
const int mod = 1e9+7;
std::string s;
ll F[_N][_N];  // 使区间 [i, j] 为合法匹配的方案数。
ll G[_N][_N];  // 使区间 [i, j] 为合法匹配的方案数，且 i, j 相互匹配。所有方案一定被 F[i][j] 包含。

inline int match(char i, char j) {
    // 特别地，"?" 可以匹配任意字符
    if (i == '?')  return match('(', j) + match('[', j) + match('{', j);
    if (j == '?')  return match(i, ')') + match(i, ']') + match(i, '}');

    return (i == '(' && j == ')') + (i == '[' && j == ']') + (i == '{' && j == '}');
}

int main() {
    initDebug;

    std::cin >> N;
    s.reserve(N);
    std::cin >> s;
    s = " "+s;
    assert((int)s.size() == N+1);

    // 将所有的 F[i+1][i] (对应一个空字符串) 设为 1
    from(i, 0, N)  F[i+1][i] = 1;

    from(l, 2, N) {  // 区间长度
        from(i, 1, N) {  // 区间左端点
            int j = i+l-1;  // 区间右端点
            if (j > N) break;

            // 这个区间的 F, G 一定是未被修改过的，直接赋值即可
            assert(F[i][j] == 0 and G[i][j] == 0);

            // 检查区间 [i, j] 是否为一个完整的括号
            // e.g. {()[]} 是完整的
            // ([{}]) 是完整的
            // 但是 {}() 不是完整的 (不过它是一个合法串)

            // 可以先检查 s[i], s[j] 两个字符是否匹配；如果匹配，则所有内部为合法串的方案都可以
            // 添加 s[i], s[j] 成为完整括号。方案数即 F[i+1][j-1] * match。
            if (match(s[i], s[j])) {
                G[i][j] = F[i+1][j-1] * match(s[i], s[j]) % mod;
            }

            // 再检查区间 [i, j] 能否成为合法串
            // 合法串：类似 []() ()[()(){}] (((())))
            // [{)] 不是合法的
            // 考虑枚举一个断点 k
            from(k, i+1, j) {  // 将区间拆分为 [i, k] 和 [k+1, j] 两个子区间
                // 我们断言：如果它的左侧是一个完串括号，右侧是一个合法串，则这个区间也是一个合法串
                F[i][j] += G[i][k] * F[k+1][j];

                // 这个断言的充分性是显然的，下面考虑它的必要性——
                // 考虑逆命题：
                // 对于每个合法串，它都能够拆分成一个完整括号和一个合法串
                // 这也是显然的，如果是多个括号并列的形式，找到前两个括号的断点即可
                // 如果是一整个，那么最终的右括号——和「空」也是这样的
                // 因此，这个断言是正确的。
                // 根据题意进行取模
                F[i][j] %= mod;
            }
        }
    }

    debug batchOutput2d(F, N+1, N+1, "%5lld");

    std::cout << F[1][N] << std::endl;
    return 0;
}