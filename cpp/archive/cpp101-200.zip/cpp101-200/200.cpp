/**
 * @link https://www.luogu.com.cn/problem/P7914
 */

#include <bits/stdc++.h>
#define initDebug DEBUG_MODE=(argc-1)&&!strcmp("-d", argv[1])
#define debug if(DEBUG_MODE)
#define log(f, a...) debug printf(f, ##a);
#define upto(i,n) for(int i=1;i<=(n);i++)
#define from(i,b,e) for(int i=(b);i<=(e);i++)
#define rev(i,e,b) for(int i=(e);i>=(b);i--)
#define main() main(int argc, char const *argv[])
#define optimizeIO std::ios::sync_with_stdio(false); std::cin.tie(0); std::cout.tie(0);
#define chkMax(base,cmp...) (base=std::max({(base),##cmp}))
#define chkMin(base,cmp...) (base=std::min({(base),##cmp}))
#define chkMaxEx(base,exchange,other,cmp...) {auto __b__=base;if(__b__!=chkMax(base,##cmp)){exchange;} else other;}
#define chkMinEx(base,exchange,other,cmp...) {auto __b__=base;if(__b__!=chkMin(base,##cmp)){exchange;} else other;}
#define update(base,op,modify...) base=op((base),##modify)
#define ensure(con, otw) ((con)? (con): (otw))
#define check(v, con, otw) (((v) con)? (v): (otw))
#define optional(ptr) if(ptr)ptr
#define never if(0)
#define always if(1)
#define bitOr(x,y) (((x)&(y))^(((x)^(y))|(~(x)&(y))))
#define Infinity 2147483647
#define putInt(n) printf("%d\n",(n))
#define compare(x,y,g,e,l) (((x)>(y))?(g):(((x)<(y))?(l):(e)))
bool DEBUG_MODE=false;
typedef long long ll; typedef unsigned long long ull;
inline void batchOutput(int *begin, int n, const char *format){upto(i, n)printf(format, begin[i]);printf("\n");} inline void batchOutput(int*begin, int n) {batchOutput(begin,n,"%3d ");}
#define batchOutput2d(b, r, c, fmt) upto(i,r){upto(j,c)printf(fmt,b[i][j]);printf("\n");}
template <class T=int>inline T read(){ T x=0;int f=1;char c;while((c=getchar())<'0'||c>'9')if(c=='-')f=-1;do{x=(((x<<2)+x)<<1)+c-'0';}while((c=getchar())>='0'&&c<='9');return x*f; }

const int _N = 505; int N; const int _K = 505; int K; int mod=1e9+7;

ll G[_N][_N];  // [i, j] 区间构成单个完整括号的方案数
ll F[_N][_N];  // [i, j] 区间构成合法串（可以是多个括号的并列）的方案数
ll prefixed[_N][_N];  // 必须包含不多于 K 个星号前缀——SA 的方案数
ll suffixed[_N][_N];  // 必须包含不多于 K 个星号后缀——AS 的方案数

char s[_N];

int match(char a, char b) {
    if (a=='?')  return match('(', b);
    if (b=='?')  return match(a, ')');
    return (int)(a=='(' && b==')');
}

int main() {
    scanf("%d", &N); scanf("%d", &K);
    initDebug;

    scanf("%s", s+1);

    // S 仅包括不超过 K 个 '*'
    // 如果 A, B 合法：
    // (), (S) 合法
    // A+B, A+S+B 合法
    // (SA), (AS) 合法

    // 特别地，空字符串不合法
    
    // 枚举所有区间
    from(l, 2, N) {  // 区间长度
        from(i, 1, N) {  // 区间左端点
            int j = i + l - 1;  // 区间右端点
            if (j > N)  break;

            // 先考虑单个完整括号的情况
            // (S), (SA), (AS) 和空括号都是可以的
            // 检测左右端点的括号
            if (match(s[i], s[j])) {
                // (S): 括号内部是一个合法串即可
                G[i][j] += F[i+1][j-1];
                // (SA): 括号内部是一个合法串，且后面接一个星号后缀
                G[i][j] += suffixed[i+1][j-1];
                // (AS): 括号内部是一个合法串，且前面接一个星号前缀
                G[i][j] += prefixed[i+1][j-1];
                // (): 空括号
                if (i+1 == j)  G[i][j] += 1;
            }

            // 再考虑合法串的情况
            // A+B, A+S+B
            // 考虑枚举一个断点 p
            from(p, i+1, j-1) {  // 分成两个子区间 [i, p] 和 [p+1, j]
                // 如果左侧是一个完整括号，右侧是任意合法串(AB)或者含前缀串(ASB)
                G[i][j] += G[i][p] * F[p+1][j];
                G[i][j] += G[i][p] * prefixed[p+1][j];
            }

            // 考虑前缀串和后缀串（不多于 K 个的星号，加上一个任意合法串）
            int lastAsterisk = i-1;
            while (lastAsterisk <= j && s[lastAsterisk+1] != '*')  lastAsterisk++;
            int firstAsterisk = j+1;
            while (firstAsterisk >= i && s[firstAsterisk-1] != '*')  firstAsterisk--;
            if (lastAsterisk-i+1 <= K)  prefixed[i][j] += F[lastAsterisk+1][j];
            if (j-firstAsterisk+1 <= K)  suffixed[i][j] += F[i][firstAsterisk-1];
        }
    }
    
    debug batchOutput2d(G, N, N, "%5lld ");
    debug batchOutput2d(F, N, N, "%5lld ");
    debug batchOutput2d(prefixed, N, N, "%5lld ");
    debug batchOutput2d(suffixed, N, N, "%5lld ");

    printf("%lld\n", F[1][N]);
    return 0;
}