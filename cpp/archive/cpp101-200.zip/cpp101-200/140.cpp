#include "lib"
int main() {
    int a = 4, b = 2, c = 3;
    chkMaxEx(a, printf("1\n"), printf("0\n"), b, c);
    return 0;
}   