#include "lib"

const int _N = 505, _M = 6005;
int N = read(), M = read();
int V[_N], W[_N], S[_N];

int main() {
    initDebug;
    std::cout << M+N << std::endl;
    return 0;
}

int L = read();