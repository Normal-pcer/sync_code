#include <cstdio>

int a=2, b=3;

int main() {
    int n;
    scanf("%d", &n);
    int result = 3;
    for (int i = 2; i < n; i++) {
        a=
    }
    if (n==2)  printf("6");
    else  printf("%d\n", result);
    return 0;
}