#include <bits/stdc++.h>

struct Number {
    int data;
    Number(int n) {this->data = n;}
    int operator+(const Number another) const;
};

int Number::operator+(const Number another) const {
    return 0;
}

int main() {
    
}