#include <cstdio>

int a[1005] = {1, 8, 73};
//         0  1  2

int main(int argc, char const *argv[]) {
    int n;
    scanf("%d", &n);
    for (int i=3; i<=n; i++) {
        a[i] = (a[])
        for (int j=1; )
    }
    if (n<=2)  printf("%d\n", a[n]);
    else  printf("%d\n", a[2]);
    return 0;
}