#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2e5+5;
int a[N];
int dp[N][2][2];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,x,y;
	cin>>n>>x>>y;
	int l=1,r=1,fgx=1,fgy=1;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	if(x==y){
		for(int i=1;i<=n;i++){
			if(a[i]<y||a[i]>x)continue;
			if(a[i]==x){
				dp[i][1][1]+=dp[i-1][1][1]+1;
			}
		}
	}else{
		for(int i=1;i<=n;i++){
			if(a[i]<y||a[i]>x)continue;
			if(a[i]==x){
				dp[i][1][0]+=dp[i-1][0][0]+dp[i-1][1][0]+1;
				dp[i][1][1]+=dp[i-1][0][1]+dp[i-1][1][1];
			}else if(a[i]==y){
				dp[i][0][1]+=dp[i-1][0][0]+dp[i-1][0][1]+1;
				dp[i][1][1]+=dp[i-1][1][0]+dp[i-1][1][1];
			}else{
				dp[i][0][0]+=dp[i-1][0][0]+1;
				dp[i][1][0]+=dp[i-1][1][0];
				dp[i][0][1]+=dp[i-1][0][1];
				dp[i][1][1]+=dp[i-1][1][1];
			}
		}	
	}
	int ans=0;
	for(int i=1;i<=n;i++){
//		cout<<dp[i][0][0]<<" "<<dp[i][0][1]<<" "<<dp[i][1][0]<<" "<<dp[i][1][1]<<"\n";
		ans+=dp[i][1][1];
	}
	cout<<ans<<"\n";
}

